package com.qualitasvita.soundmind.adapters;

import android.content.Context;
import android.support.annotation.NonNull;
import android.widget.ArrayAdapter;

import com.qualitasvita.soundmind.Answer;
import com.qualitasvita.soundmind.Note;

public class mainAdapter extends ArrayAdapter<Note> {
    public mainAdapter(@NonNull Context context, int resource) {
        super(context, resource);
    }
}
